/*
    FreeRTOS V8.0.1 - Copyright (C) 2014 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

// FreeRTOS.org includes
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"

// Library includes
#include "LPC17xx.h"

// Demo includes
#include "basic_io.h"
#include "lpc17xx_gpio.h"

// #defines 
#define ADC_SMARTBULB_ON_THRESHOLD 2048		// If ADC reading less than 2048, bulb will turn ON [full scale 4096]
#define ADC_AVERAGE 10
#define ADC_RATE 150000						// ADC clk 150KHz
#define DONE_STATUS 1
#define BURST_STATUS 0
#define CHANNEL_0 0

#define LED_PIN_NUM 22
#define LED_PIN_BIT (1 << LED_PIN_NUM)

#define PIR_SENSOR_PIN_NUM 0
#define PIR_SENSOR_PIN_BIT (1 << PIR_SENSOR_PIN_NUM)

#define RISING_EDGE_INT_PORT_0_9 (1 << 9)
#define RISING_EDGE 0

#define PORT_0 0
#define PORT_2 2

#define ENABLE 1
#define DISABLE 0

#define LIGHT_INTENSITY_THRESHOLD_0	0				// full scale of 4096 divided into 8 levels
#define LIGHT_INTENSITY_THRESHOLD_1 512
#define LIGHT_INTENSITY_THRESHOLD_2 1024
#define LIGHT_INTENSITY_THRESHOLD_3 1536
#define LIGHT_INTENSITY_THRESHOLD_4 2048
#define LIGHT_INTENSITY_THRESHOLD_5 2560
#define LIGHT_INTENSITY_THRESHOLD_6 3072
#define LIGHT_INTENSITY_THRESHOLD_7 3584

#define DISPLAY_0 0x3F		// pulling pin low implies that segment will glow
#define DISPLAY_1 0x06
#define DISPLAY_2 0x5B
#define DISPLAY_3 0x4F
#define DISPLAY_4 0x66
#define DISPLAY_5 0x6D
#define DISPLAY_6 0x7D
#define DISPLAY_7 0x07
#define DISPLAY_8 0x7F

// The task function declarations
void TimerTask( void * pvParameters );
void ButtonTask( void *pvParameters );
void ADCTask( void *pvParameters );
void SmartBulbTask( void *pvParameters );
void PIRSensorTask( void *pvParameters );
void _7SegmentDisplayTask( void *pvParameters );

// Semaphore that is used to synchronize the ADC task with the ADC interrupt
xSemaphoreHandle ADC_Int_ADC_Tsk_Semaphore;
// Semaphore that is used to synchronize the External Interrupt task with the EXT_INT interrupt
xSemaphoreHandle EXT_Int_EXT_Tsk_Semaphore;

// Queue to store ADC readings that will be averaged...
xQueueHandle ADCQueue;

// Task Handles
xTaskHandle TimerTaskHandle, ButtonTaskHandle, ADCTaskHandle, SmartBulbTaskHandle, PIRSensorTaskHandle;

// global variable declaration
bool led_on_ext_int = false;
bool led_on_adc = false;
bool led_on_pir = false;

unsigned int num_adc_readings = 0;

unsigned int light_intensity = 0;		// holds light intensity from current cycle of ADC measurement
unsigned int prev_light_intensity = 0;	// holds light intensity from previous cycle of ADC measurement

/*-----------------------------------------------------------*/

// Initialize all the I/O pins as either analog/digital, input/output, etc.
void GPIO_Initialization(void)
{
	// Push Button
	// configure P0.9 for gpio functionality
	LPC_PINCON->PINSEL0 &= (~(3 << 18));
	// configure P0.9 as input reset the right bit to '0'
    LPC_GPIO0->FIODIR &= (~(1 << 9));

	// LDR
	// configure ADC 0-7 pins for ADC functionality
	LPC_PINCON->PINSEL0 &= ~0x000000F0;		// P0.2-3, A0.6-7, function 10
	LPC_PINCON->PINSEL0 |= 0x000000A0;

	LPC_PINCON->PINSEL1 &= ~0x003FC000;		// P0.23-26, A0.0-3, function 01
	LPC_PINCON->PINSEL1 |= 0x00154000;

	LPC_PINCON->PINSEL3 |= 0xF0000000;		// P1.30-31, A0.4-5, function 11

	// select neither pull-up nor pull-down (function 10) on all ADC pins
	LPC_PINCON->PINMODE0 &= ~0x000000F0;
	LPC_PINCON->PINMODE0 |= 0x000000A0;

	LPC_PINCON->PINMODE1 &= ~0x003FC000;
	LPC_PINCON->PINMODE1 |= 0x002A8000;

	LPC_PINCON->PINMODE3 &= ~0xF0000000;
	LPC_PINCON->PINMODE3 |= 0xA0000000;

	// RED LED as smart bulb
	// Now configure the right bits in the pin selection regiser #1 P0.22
	LPC_PINCON->PINSEL1 &= (~(3 << 12));
	// Now set the right bit to '1' in this register to set the gpio direction to output P0.22
	LPC_GPIO0->FIODIR |= (1 << 22);

	// 7-Segment Display
	// setup gpio P2.0 to P2.8 digital I/O, function '00' for 18 LSB bits
	LPC_PINCON->PINSEL4 &= 0xFFFC0000;
	// setup gpio P2.0 to P2.8 digital output - set the 9 LSB bits to '1'
	LPC_GPIO2->FIODIR |= 0x000001FF;

	// PIR sensor:
	// setup gpio P0.0 as digital I/O, function '00' for LSB bit
	LPC_PINCON->PINSEL0 &= (~(3 << 0));
	// setup gpio P0.0 as digital input, set the LSB bit to '0'
    LPC_GPIO0->FIODIR |= (~(1 << 0));
}
/*-----------------------------------------------------------*/

// External interrupt on rising edge for push button on gpio P0.9
void External_Interrupt_Initialization(void)
{
	// enable rising edge interrupts on gpio pin
	GPIO_IntCmd(PORT_0, RISING_EDGE_INT_PORT_0_9, RISING_EDGE);		// LPC_GPIOINT->IO0IntEnR |= (1 << 9);

    /*
    * @brief  Set the priority for an interrupt
    * @param  IRQn      The number of the interrupt for set priority
    * @param  priority  The priority to set
    */
	NVIC_SetPriority( EINT3_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY);

	/*
	* @brief  Enable Interrupt in NVIC Interrupt Controller
	* @param  IRQn   The positive number of the external interrupt to enable
	*/
	NVIC_EnableIRQ(EINT3_IRQn);
}
/*-----------------------------------------------------------*/

void ADC_Initialization( void )
{
	/*********************************************************************
	 * @brief 		Initial for ADC
	 * 					+ Set bit PCADC
	 * 					+ Set clock for ADC
	 * 					+ Set Clock Frequency
	 * @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
	 * @param[in]	rate ADC conversion rate, should be <=200KHz
	 * @return 		None
	 *********************************************************************/ 
	ADC_Init(LPC_ADC, ADC_RATE);

	ADC_StartCmd(LPC_ADC, ADC_START_CONTINUOUS);		// Stop ADC conversion
	ADC_IntConfig(LPC_ADC, ADC_ADGINTEN, ENABLE);		// Enable ADC Individual channel/global flag done to generate an interrupt 
														// ADC channel 0, AD0[0] on P0.23
	ADC_BurstCmd(LPC_ADC, DISABLE);						// Disable BURST mode
    
	/*
    * @brief  Set the priority for an interrupt
    * @param  IRQn      The number of the interrupt for set priority
    * @param  priority  The priority to set
    */
	NVIC_SetPriority( ADC_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY);
	
	/*
	* @brief  Enable Interrupt in NVIC Interrupt Controller
	* @param  IRQn   The positive number of the external interrupt to enable
	*/
	NVIC_EnableIRQ(ADC_IRQn);

	return;
}
/*-----------------------------------------------------------*/

// ISR for External interrupt on rising edge for push button on gpio P0.9
void EINT3_IRQHandler (void)
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	if(GPIO_GetIntStatus(PORT_0, 9, RISING_EDGE)				// rising edge interrupt on P0.9 was fired
	{
		GPIO_ClearInt(PORT_0, RISING_EDGE_INT_PORT_0_9);		// clear the interrupt bit
		printf("EINT3_IRQHandler: Push button rising edge interrupt detected on P0.9 \n");
		
		// 'Give' the semaphore to unblock the task
		xSemaphoreGiveFromISR( EXT_Int_EXT_Tsk_Semaphore, &xHigherPriorityTaskWoken );	
	}
	/*
	if (LPC_GPIOINT->IO0IntStatR & (1 << 9))
	{
		//rising edge interrupt on pin 0.9 was fired
		LPC_GPIOINT->IO0IntClr |= (1 << 9); // clear the status
		printf("rising edge on gpio: p0[9]\n");
	}
	if (LPC_GPIOINT->IO0IntStatF & (1 << 9))
	{
		//falling edge interrupt on pin 0.9 was fired
		LPC_GPIOINT->IO0IntClr |= (1 << 9); // clear the status
		printf("falling edge on gpio: p0[9]\n");
	}
	*/

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.

	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports.  The portEND_SWITCHING_ISR() macro is provided as part of
	the Cortex-M3 port layer for this purpose.  taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

// ISR for ADC Channel 0 interrupt
void ADC_IRQHandler(void)
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	unsigned int adc_reading = 0;

	if(ADC_ChannelGetStatus(LPC_ADC, CHANNEL_0, DONE_STATUS))	// check if DONE flag is set due to completion of ADC conversion on AD0 Ch_0
	{
		ADC_StartCmd(LPC_ADC, ADC_START_CONTINUOUS);			// Stop ADC conversion
		adc_reading = ADC_ChannelGetData(LPC_ADC, CHANNEL_0);	// Read the result from Ch_0 data register
		xQueueSendFromISR(ADCQueue, &adc_reading);				// Send the data to the ADCQueue
		printf("ADC_IRQHandler: ADC reading[%u] = %u \n", num_adc_readings, adc_reading);	// Debug only
		num_adc_readings++;

		if(num_adc_readings >= ADC_AVERAGE)
		{
			ADC_StartCmd(LPC_ADC, ADC_START_CONTINUOUS);		// Stop ADC conversion, one averaging cycle is over
			xSemaphoreGiveFromISR( ADC_Int_ADC_Tsk_Semaphore, &xHigherPriorityTaskWoken );	// 'Give' the semaphore to unblock the ADC handler task
		}
		else
		{
			ADC_StartCmd(LPC_ADC, ADC_START_NOW);				// Start next ADC conversion in current cycle
		}
	}

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.

	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports.  The portEND_SWITCHING_ISR() macro is provided as part of
	the Cortex-M3 port layer for this purpose. taskYIELD() must never be called from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

int main( void )
{
	// Initialize the semi-hosting
	printf( "\n" );

	// Create binary semaphores
    xSemaphoreCreateBinary( ADC_Int_ADC_Tsk_Semaphore );
	xSemaphoreCreateBinary( EXT_Int_EXT_Tsk_Semaphore );

	// The queue is created to hold a maximum of 'NUM_ADC_READINGS' long values
    ADCQueue = xQueueCreate( ADC_AVERAGE, sizeof( unsigned int ) );

	// Initialize the peripherals/interrupts
	GPIO_Initialization();
	External_Interrupt_Initialization();
	ADC_Initialization();
    
	// Create tasks here...
	if( ADCQueue != NULL )
	{
		xTaskCreate(	SmartBulbTask,				// Pointer to the function that implements the task.
						"SmartBulb_Task",			// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						2,							// This task will run at priority 
						SmartBulbTaskHandle );		// the task handle.

		xTaskCreate(	PIRSensorTask,				// Pointer to the function that implements the task.
						"PIRSensor_Task",			// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						3,							// This task will run at priority 
						PIRSensorTaskHandle );		// the task handle.

		xTaskCreate(	ADCTask,					// Pointer to the function that implements the task.
						"ADC_Task",					// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						3,							// This task will run at priority 
						ADCTaskHandle );			// the task handle.

		xTaskCreate(	ButtonTask,					// Pointer to the function that implements the task.
						"Button_Task",				// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						4,							// This task will run at priority 
						ButtonTaskHandle );			// the task handle.

		xTaskCreate(	TimerTask,					// Pointer to the function that implements the task.
						"Timer_Task",				// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						5,							// This task will run at priority 
						TimerTaskHandle );			// the task handle.

		// Start the scheduler so our tasks start executing
		vTaskStartScheduler();
	}
	else
	{
		// The queue could not be created, no space in the heap...
		printf("The queue could not be created, no space in the heap...\n");		// Debug only
	}

	/* If all is well we will never reach here as the scheduler will now be running.  
	If we do reach here then it is likely that there was insufficient heap available for the idle task to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

 // Task to start ADC conversion for each averaging cycle after 1 sec intervals
 void TimerTask( void * pvParameters )
 {
	portTickType xLastWakeTime;
	const portTickType WakeUpInterval = 1000 / portTICK_RATE_MS;

	// Initialise the xLastWakeTime variable with the current time.
	xLastWakeTime = xTaskGetTickCount();

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		// Periodic interrupts of 1sec for the ADC start...
		vTaskDelayUntil( &xLastWakeTime, WakeUpInterval );	// 1 sec.

		// Perform action here: Enable the ADC channel and start conversion
		printf("TimerTask: One sec timer task entered. ADC starting now...\n");		// Debug only

		num_adc_readings = 0;								// initialize variable to count the averaging cycle...
		ADC_ChannelCmd(LPC_ADC, CHANNEL_0, ENABLE);			// Enable ADC Ch_0
		ADC_StartCmd(LPC_ADC, ADC_START_NOW);				// Start next ADC conversion cycle
	}
 }
 /*-----------------------------------------------------------*/

// Task to handle the processing from the EXT_INT interrupt using the push button
void ButtonTask( void *pvParameters )
{
	uint32_t port_0_status;

	/* Take the semaphore once to start with so the semaphore is empty before the infinite loop is entered.  
	   The semaphore was created before the scheduler was started so before this task ran for the first time. */
	xSemaphoreTake( EXT_Int_EXT_Tsk_Semaphore, 0 );

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		/* Use the semaphore to wait for the event. The task blocks indefinitely meaning this function call will only return once the
		   semaphore has been successfully obtained - so there is no need to check the returned value. */
		xSemaphoreTake( EXT_Int_EXT_Tsk_Semaphore, portMAX_DELAY );

		// To get here the event must have occurred. Process the event, in this case check if we need to enable/disable smart mode
		port_0_status = GPIO_ReadValue(PORT_0);

		// LED is already ON, turn OFF and 'enable' smart mode/'disable' push button override
		if(port_0_status >> LED_PIN_NUM) & 0x1)		
		{
			printf("ButtonTask: LED is already ON, turn OFF and 'enable' smart mode/'disable' push button override \n");	// Debug only
			GPIO_SetValue(PORT_0, LED_PIN_BIT);		// LPC_GPIO0->FIOSET = (1 << 22);
			led_on_ext_int = false;
		}
		// LED is OFF, turn ON, smart mode 'disabled'/'enable' push button override
		else										
		{
			printf("ButtonTask: LED is OFF, turn ON, smart mode 'disabled'/'enable' push button override \n");				// Debug only
			GPIO_ClearValue(PORT_0, LED_PIN_BIT);	// LPC_GPIO0->FIOCLR = (1 << 22);
			led_on_ext_int = true;
		}
	}
}
/*-----------------------------------------------------------*/

// Task to check the PIR sensor, a '1' on the pin indicates that is motion detected
void PIRSensorTask( void *pvParameters )
{
	portTickType xLastWakeUpTime;
	const portTickType WakeUpInterval = 197 / portTICK_PERIOD_MS;

	// Initialise the xLastWakeUpTime variable with the current time.
    xLastWakeUpTime = xTaskGetTickCount();

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		vTaskDelayUntil( &xLastWakeUpTime, WakeUpInterval );
				
		// To get here the periodic time interval is over, take action
		port_0_status = GPIO_ReadValue(PORT_0);

		if(port_0_status >> PIR_SENSOR_PIN_NUM) & 0x1)			// PIR sensor is high, motion detected
		{
			printf("PIRSensorTask: Motion detected \n");		// Debug only
			led_on_pir = true;
		}
		else													// PIR sensor is low, no motion detected
		{
			printf("PIRSensorTask: No motion detected \n");		// Debug only
			led_on_pir = false;
		}
	}
}
/*-----------------------------------------------------------*/

// Task to handle the data processing from the ADC interrupt
void ADCTask( void *pvParameters )
{
	unsigned int i = 0;
	unsigned int adc_queue_reading = 0;
	unsigned int adc_queue_reading_sum = 0;
	unsigned int adc_average_reading;
	
	/* Take the semaphore once to start with so the semaphore is empty before the infinite loop is entered.  
	   The semaphore was created before the scheduler was started so before this task ran for the first time. */
	xSemaphoreTake( ADC_Int_ADC_Tsk_Semaphore, 0 );

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		/* Use the semaphore to wait for the event.  The task blocks indefinitely meaning this function call will only return once the
		   semaphore has been successfully obtained - so there is no need to check the returned value. */
		xSemaphoreTake( ADC_Int_ADC_Tsk_Semaphore, portMAX_DELAY );

		// To get here the event must have occurred (semaphore acquired).  Process the event, in this case read the values from the queue
		if((ADCQueue != NULL) && (uxQueueMessagesWaiting(ADCQueue) == ADC_AVERAGE))
		{
			for(i = 0; i < ADC_AVERAGE; i++)
			{
				// for successful receive from the queue as well check if queue is not empty
				if((xQueueReceive(ADCQueue, (void *)&adc_queue_reading, (TickType_t)5 )) && (uxQueueMessagesWaiting(ADCQueue) != 0))
				{
					printf("ADCTask: ADC reading[%u] = %u \n", i, adc_queue_reading);	// Debug only
					adc_queue_reading_sum += adc_queue_reading;
				}
			}
			printf("ADCTask: adc_queue_reading_sum = %u \n", adc_queue_reading_sum);	// Debug only
			adc_queue_reading_sum = 0;
			adc_average_reading = adc_queue_reading_sum/ADC_AVERAGE;
			
			// take decision to turn on/off LED based on the ADC readings
			if(adc_average_reading < ADC_SMARTBULB_ON_THRESHOLD) led_on_adc = true;
			else												 led_on_adc = false;

			// check the intensity of the light...
			if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_7)      light_intensity = 8;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_6) light_intensity = 7;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_5) light_intensity = 6;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_4) light_intensity = 5;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_3) light_intensity = 4;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_2) light_intensity = 3;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_1) light_intensity = 2;
			else if(adc_average_reading > LIGHT_INTENSITY_THRESHOLD_0) light_intensity = 1;
			else													   light_intensity = 0;
		}
		else
		{
			// The queue could not be created, no space in the heap...
		}
	}
}
/*-----------------------------------------------------------*/

/* Task to check if we need to turn ON/OFF the smart bulb...
   The smart bulb will be turned ON if the push button was pressed once (turned OFF if pressed again), 
   irrespective of whether the ADC_THRESHOLD is reached and/or the PIR sensor detects any motion.
*/
void SmartBulbTask( void *pvParameters )
{
	portTickType xLastWakeUpTime;
	const portTickType WakeUpInterval = 53 / portTICK_PERIOD_MS;

	// Initialise the xLastWakeUpTime variable with the current time.
    xLastWakeUpTime = xTaskGetTickCount();

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		vTaskDelayUntil( &xLastWakeUpTime, WakeUpInterval );
				
		// To get here the periodic time interval is over, take action
		if(led_on_ext_int || (led_on_adc && led_on_pir))	GPIO_ClearValue(PORT_0, LED_PIN_BIT);	// Turn ON LED,  LPC_GPIO0->FIOCLR = (1 << 22);
		else												GPIO_SetValue(PORT_0, LED_PIN_BIT);		// Turn OFF LED, LPC_GPIO0->FIOSET = (1 << 22);

		if(prev_light_intensity != light_intensity)			// change the 7-segment display only if light intensity varied...
		{
			GPIO_SetValue(PORT_2, DISPLAY_8);				// turn off all segments
			
			// display light intensity on the 7-segment display
			switch(light_intensity)
			{
				case 1:	GPIO_ClearValue(PORT_2, DISPLAY_1); break;	// 0x06
				case 2:	GPIO_ClearValue(PORT_2, DISPLAY_2); break;	// 0x5B
				case 3:	GPIO_ClearValue(PORT_2, DISPLAY_3); break;	// 0x4F
				case 4:	GPIO_ClearValue(PORT_2, DISPLAY_4); break;	// 0x66
				case 5:	GPIO_ClearValue(PORT_2, DISPLAY_5); break;	// 0x6D
				case 6:	GPIO_ClearValue(PORT_2, DISPLAY_6); break;	// 0x7D
				case 7:	GPIO_ClearValue(PORT_2, DISPLAY_7); break;	// 0x07
				case 8:	GPIO_ClearValue(PORT_2, DISPLAY_8); break;	// 0x7F
			   default: GPIO_ClearValue(PORT_2, DISPLAY_0); break;	// 0x3F
			}

			prev_light_intensity = light_intensity;
		}
	}
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* This function will only be called if an API call to create a task, queue
	or semaphore fails because there is too little heap RAM remaining. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed char *pcTaskName )
{
	/* This function will only be called if a task overflows its stack.  Note
	that stack overflow checking does slow down the context switch
	implementation. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
	/* This example does not use the idle hook to perform any processing. */
}
/*-----------------------------------------------------------*/

void vApplicationTickHook( void )
{
	/* This example does not use the tick hook to perform any processing. */
}
