/*
    FreeRTOS V8.0.1 - Copyright (C) 2014 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
    ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public
    License and the FreeRTOS license exception along with FreeRTOS; if not it
    can be viewed here: http://www.freertos.org/a00114.html and also obtained
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
*/

// FreeRTOS.org includes
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "queue.h"
#include "debug_frmwrk.h"

// Library includes
#include "LPC17xx.h"

// Demo includes
#include "basic_io.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_exti.h"
#include "lpc17xx_nvic.h"
#include "lpc17xx_i2c.h"

// #defines 
#define DEBUG_PRINT

// ADC
#define ADC_SMARTBULB_ON_THRESHOLD 1200		// If ADC reading less than 1200, bulb will turn ON [full scale 4096]
#define NUM_READING_PER_CH 5
#define ADC_RATE 150000						// ADC clk 150KHz
#define DONE_STATUS 1
#define BURST_STATUS 0
#define CHANNEL_0 0
#define CHANNEL_1 1
#define CHANNEL_2 2
#define CHANNEL_3 3
#define CHANNEL_4 4
#define CHANNEL_5 5
#define CHANNEL_6 6
#define CHANNEL_7 7
/*
// In ADC module, AD0CR[7:0] -> SEL[7:0], only one bit should be '1' at any time..
enum CHANNEL{	CHANNEL_0 = (1<<0), 	// AD0 CH0
				CHANNEL_1 = (1<<1), 	// AD0 CH1
				CHANNEL_2 = (1<<2), 	// AD0 CH2
				CHANNEL_3 = (1<<3), 	// AD0 CH3
				CHANNEL_4 = (1<<4), 	// AD0 CH4
				CHANNEL_5 = (1<<5), 	// AD0 CH5
				CHANNEL_6 = (1<<6), 	// AD0 CH6
				CHANNEL_7 = (1<<7)  	// AD0 CH7
			};
*/
#define NUM_ADC_CH 8

// I2C
#define I2C_CLK 100000						// I2C clk 100KHz
#define I2C_MASTER LPC_I2C1					// I2C1 module is the Master
#define I2C_DUMMY LPC_I2C0					// I2C0 module is the dummy module
#define EEPROM_ADDR_24LC64 0x50				// 7-bit I2C slave address of the 24LC64 EEPROM

#define WR_BUFFER_SIZE 18					// 2-byte starting address + 16-byte write
#define RD_BUFFER_SIZE 16					// 16-byte read
#define WRITE_DATA_START 2					// first 2-bytes is for the starting address to write from in eeprom

// GPIO
#define LED_PIN_NUM 22
#define LED_PIN_BIT (1 << LED_PIN_NUM)

#define RISING_EDGE_INT_PORT_0_9 (1 << 9)
#define RISING_EDGE 0

#define PORT_0 0
#define PORT_2 2

// General
#define ENABLE 1
#define DISABLE 0
#define true 1
#define false 0


// The task function declarations
void TimerTask( void * pvParameters );
void ButtonTask( void *pvParameters );
void ADCTask( void *pvParameters );
void I2CTask( void *pvParameters );


// Semaphore that is used to synchronize the ADC task with the ADC interrupt
xSemaphoreHandle ADC_Int_ADC_Tsk_Semaphore;
// Semaphore that is used to synchronize the ADC task with the I2C task to write data to EEPROM
xSemaphoreHandle ADC_Tsk_I2C_Tsk_Semaphore;
// Semaphore that is used to synchronize the External Interrupt task with the EXT_INT interrupt
xSemaphoreHandle EXT_Int_EXT_Tsk_Semaphore;

// Queue to store ADC readings that will be averaged...
xQueueHandle ADCQueue;

// Task Handles
xTaskHandle TimerTaskHandle, ButtonTaskHandle, ADCTaskHandle, SmartBulbTaskHandle, I2CTaskHandle;

// global variable declaration
uint8_t num_adc_readings, num_adc_readings_per_ch, current_adc_channel;
unsigned long int port_0_status;
uint8_t Master_WR_Buffer[WR_BUFFER_SIZE];
uint8_t Master_RD_Buffer[RD_BUFFER_SIZE];
I2C_M_SETUP_Type Master_tx_rx_setup;
__IO FlagStatus MasterTransferComplete;
uint8_t master_wr_index, master_rd_index;

/*-----------------------------------------------------------*/

// Initialize all the I/O pins as either analog/digital, input/output, etc.
void GPIO_Initialization(void)
{
	// Push Button
	// configure P0.9 for gpio functionality
	LPC_PINCON->PINSEL0 &= (~(3 << 18));
	// configure P0.9 as input reset the right bit to '0'
    //LPC_GPIO0->FIODIR &= (~(1 << 9));

	// Analog inputs
	// configure ADC 0-7 pins for ADC functionality
	LPC_PINCON->PINSEL0 &= ~0x000000F0;		// pinsel0[7:4] -> P0.2-3, A0.6-7, function 10
	LPC_PINCON->PINSEL0 |= 0x000000A0;

	LPC_PINCON->PINSEL1 &= ~0x003FC000;		// pinsel[21:14] -> P0.23-26, A0.0-3, function 01
	LPC_PINCON->PINSEL1 |= 0x00154000;

	LPC_PINCON->PINSEL3 |= 0xF0000000;		// pinsel3[31:28] -> P1.30-31, A0.4-5, function 11

	// select neither pull-up nor pull-down (function 10) on all ADC pins
	LPC_PINCON->PINMODE0 &= ~0x000000F0;	// pinmode0[7:4] -> P0.2-3, A0.6-7, function 10
	LPC_PINCON->PINMODE0 |= 0x000000A0;

	LPC_PINCON->PINMODE1 &= ~0x003FC000;	// pinmode1[21:14] -> P0.23-26, A0.0-3, function 10
	LPC_PINCON->PINMODE1 |= 0x002A8000;

	LPC_PINCON->PINMODE3 &= ~0xF0000000;	// pinmode3[31:28] -> P1.30-31, A0.4-5, function 10
	LPC_PINCON->PINMODE3 |= 0xA0000000;

	// RED LED as smart bulb
	// Now configure the right bits in the pin selection regiser #1 P0.22
	LPC_PINCON->PINSEL1 &= (~(3 << 12));
	// Now set the right bit to '1' in this register to set the gpio direction to output P0.22
	LPC_GPIO0->FIODIR |= (1 << 22);

	// I2C0/1
	// setup I2C1 functions on P0.19 & P0.20, function '11' for bits [9:6]
	// setup I2C0 functions on P0.27 & P0.28, function '01' for bits [25:22]
	LPC_PINCON->PINSEL1 |= 0x014003C0;
	// select neither pull up nor pull down on any I2C pin, '10' for bits [9:6]
	LPC_PINCON->PINMODE1 |= 0x00000280;
    // enable open drain on I2C pins, '1' for bits [20:19]
    LPC_PINCON->PINMODE_OD0 |= 0x00180000;
    // for I2C0 - standard drive mode, glitch filtering and slew rate control enabled
    LPC_PINCON->I2CPADCFG = 0;
}
/*-----------------------------------------------------------*/

// External interrupt on rising edge for push button on gpio P0.9
void External_Interrupt_Initialization(void)
{
	// enable rising edge interrupts on gpio pin
	GPIO_IntCmd(PORT_0, RISING_EDGE_INT_PORT_0_9, RISING_EDGE);		// LPC_GPIOINT->IO0IntEnR |= (1 << 9);

    /*
    * @brief  Set the priority for an interrupt
    * @param  IRQn      The number of the interrupt for set priority
    * @param  priority  The priority to set
    */
	NVIC_SetPriority( EINT3_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY);

	/*
	* @brief  Enable Interrupt in NVIC Interrupt Controller
	* @param  IRQn   The positive number of the external interrupt to enable
	*/
	NVIC_EnableIRQ(EINT3_IRQn);
}
/*-----------------------------------------------------------*/

void ADC_Initialization( void )
{
	current_adc_channel = CHANNEL_0;					// Current ADC 'CH_0', AD0[0] on P0.23
	num_adc_readings = 0;
	num_adc_readings_per_ch = 0;

	/*********************************************************************
	 * @brief 		Initial for ADC
	 * 					+ Set bit PCADC
	 * 					+ Set clock for ADC
	 * 					+ Set Clock Frequency
	 * @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
	 * @param[in]	rate ADC conversion rate, should be <=200KHz
	 * @return 		None
	 *********************************************************************/ 
	ADC_Init(LPC_ADC, ADC_RATE);

	/*********************************************************************//**
	* @brief 		Set start mode for ADC
	* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
	* @param[in]	start_mode Start mode choose one of modes in
	* 				'ADC_START_OPT' enumeration type definition, should be:
	* 				- ADC_START_CONTINUOUS
	* 				- ADC_START_NOW
	* 				- ADC_START_ON_EINT0
	* 				- ADC_START_ON_CAP01
	*				- ADC_START_ON_MAT01
	*				- ADC_START_ON_MAT03
	*				- ADC_START_ON_MAT10
	*				- ADC_START_ON_MAT11
	* @return 		None
	*********************************************************************/
	ADC_StartCmd(LPC_ADC, ADC_START_CONTINUOUS);		// Stop ADC conversion

	/*********************************************************************//**
	* @brief 		ADC interrupt configuration
	* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
	* @param[in]	IntType: type of interrupt, should be:
	* 				- ADC_ADINTEN0: Interrupt channel 0
	* 				- ADC_ADINTEN1: Interrupt channel 1
	* 				...
	* 				- ADC_ADINTEN7: Interrupt channel 7
	* 				- ADC_ADGINTEN: Individual channel/global flag done generate an interrupt
	* @param[in]	NewState:
	* 				- SET : enable ADC interrupt
	* 				- RESET: disable ADC interrupt
	* @return 		None
	**********************************************************************/
	ADC_IntConfig(LPC_ADC, ADC_ADGINTEN, RESET);

	/*********************************************************************//**
	* @brief 		ADC Burst mode setting
	* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
	* @param[in]	NewState
	* 				-	1: Set Burst mode
	* 				-	0: reset Burst mode
	* @return 		None
	**********************************************************************/
	ADC_BurstCmd(LPC_ADC, DISABLE);
    
	/*
    * @brief  Set the priority for an interrupt
    * @param  IRQn      The number of the interrupt for set priority
    * @param  priority  The priority to set
    */
	NVIC_SetPriority( ADC_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY);
	
	/*
	* @brief  Enable Interrupt in NVIC Interrupt Controller
	* @param  IRQn   The positive number of the external interrupt to enable
	*/
	NVIC_DisableIRQ(ADC_IRQn);

	return;
}
/*-----------------------------------------------------------*/

// Initialize I2C0/1 module
void I2C_Initialization(void)
{
	unsigned int i = 0;
	master_wr_index = WRITE_DATA_START;
	master_rd_index = 0;

	// initialize master_wr_buffer, Master_WR_Buffer[0] & [1] are the starting address which is set to '0'
	for(i = 0; i < WR_BUFFER_SIZE; i++) Master_WR_Buffer[i] = 0;

	// initialize the 'Master_tx_rx_setup' structure for read/write data
	Master_tx_rx_setup.sl_addr7bit = EEPROM_ADDR_24LC64;
	Master_tx_rx_setup.tx_data = NULL;
	Master_tx_rx_setup.tx_length = 0;
	Master_tx_rx_setup.rx_data = NULL;
	Master_tx_rx_setup.rx_length = 0;
	Master_tx_rx_setup.retransmissions_max = 0;

	/********************************************************************//**
	 * @brief		Initializes the I2Cx peripheral with specified parameter.
	 * @param[in]	I2Cx	I2C peripheral selected, should be
	 * 				- LPC_I2C0
	 * 				- LPC_I2C1
	 * 				- LPC_I2C2
	 * @param[in]	clockrate Target clock value to initialize I2C peripheral (Hz)
	 * @return 		None
	 *********************************************************************/
	 I2C_Init(I2C_MASTER, I2C_CLK);
	 //I2C_Init(I2C_DUMMY, I2C_CLK);

     /*
	 * @brief  Set the priority for an interrupt
	 * @param  IRQn      The number of the interrupt for set priority
	 * @param  priority  The priority to set
	 */
	 NVIC_SetPriority( I2C1_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY);
	 //NVIC_SetPriority( I2C0_IRQn, configMAX_SYSCALL_INTERRUPT_PRIORITY);

	 /*
	 * @brief  Disable Interrupt in NVIC Interrupt Controller
	 * @param  IRQn   The positive number of the external interrupt to enable
	 */
	 // NOTE: In I2C_MasterTransferData(), I2C_IntCmd() will be called which in turn calls
	 // NVIC_EnableIRQ(I2C1_IRQn) enabling the interrupt
	 NVIC_DisableIRQ(I2C1_IRQn);
	 //NVIC_DisableIRQ(I2C0_IRQn);

	 /*********************************************************************//**
	  * @brief		Enable or disable I2C peripheral's operation, I2EN bit = 1
	  * @param[in]	I2Cx I2C peripheral selected, should be
	  *  			- LPC_I2C0
	  * 			- LPC_I2C1
	  * 			- LPC_I2C2
	  * @param[in]	NewState New State of I2Cx peripheral's operation
	  * @return 	none
	  **********************************************************************/
	  I2C_Cmd(I2C_MASTER, ENABLE);
	  //I2C_Cmd(I2C_DUMMY, ENABLE);
}
/*-----------------------------------------------------------*/

// ISR for External interrupt on rising edge for push button on gpio P0.9
void EINT3_IRQHandler (void)
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
	
	if(GPIO_GetIntStatus(PORT_0, 9, RISING_EDGE))				// rising edge interrupt on P0.9 was fired
	{
		GPIO_ClearInt(PORT_0, RISING_EDGE_INT_PORT_0_9);		// clear the interrupt bit
		//printf("EINT3_IRQHandler: _|-\n");
		
		// 'Give' the semaphore to unblock the task
		xSemaphoreGiveFromISR( EXT_Int_EXT_Tsk_Semaphore, &xHigherPriorityTaskWoken );	
	}
	/*
	if (LPC_GPIOINT->IO0IntStatR & (1 << 9))
	{
		//rising edge interrupt on pin 0.9 was fired
		LPC_GPIOINT->IO0IntClr |= (1 << 9); // clear the status
		printf("rising edge on gpio: p0[9]\n");
	}
	if (LPC_GPIOINT->IO0IntStatF & (1 << 9))
	{
		//falling edge interrupt on pin 0.9 was fired
		LPC_GPIOINT->IO0IntClr |= (1 << 9); // clear the status
		printf("falling edge on gpio: p0[9]\n");
	}
	*/

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.

	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports.  The portEND_SWITCHING_ISR() macro is provided as part of
	the Cortex-M3 port layer for this purpose.  taskYIELD() must never be called
	from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

// ISR for ADC interrupt
void ADC_IRQHandler(void)
{
	portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;

	unsigned int adc_reading = 0;

	/*********************************************************************//**
	* @brief 		Get ADC Channel status from AD global data register
	* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
	* @param[in]  	StatusType
	*              	0: Burst status
	*               1: Done status
	* @return 		SET / RESET
	**********************************************************************/
	if(ADC_ChannelGetStatus(LPC_ADC, current_adc_channel, DONE_STATUS))
	{
		ADC_StartCmd(LPC_ADC, ADC_START_CONTINUOUS);							// Stop ADC conversion

		/*********************************************************************//**
		* @brief 		Get ADC result
		* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
		* @param[in]	channel: channel number, should be either of 0,1,2,3,4,5,6,7
		* @return 		Data conversion
		**********************************************************************/
		adc_reading = ADC_ChannelGetData(LPC_ADC, current_adc_channel);
		/*********************************************************************//**
		* @brief 		Get ADC Data from AD Global register
		* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
		* @return 		Result of conversion
		**********************************************************************/
		//adc_reading = ADC_GlobalGetData(LPC_ADC);

		xQueueSendFromISR(ADCQueue, &adc_reading, &xHigherPriorityTaskWoken);	// Send the data to the ADCQueue

		#ifdef DEBUG_PRINT 		// Debug only
			printf("ADC_IRQHandler: CH = %u[%u] = %u\n", current_adc_channel, num_adc_readings, adc_reading);
		#endif

		num_adc_readings++;
		num_adc_readings_per_ch++;

		if(num_adc_readings >= (NUM_READING_PER_CH*NUM_ADC_CH))
		{
			// Stop ADC conversion, one entire cycle is over (ch0 - ch7)
			ADC_StartCmd(LPC_ADC, ADC_START_CONTINUOUS);
			// 'Give' the semaphore to unblock the ADC handler task
			xSemaphoreGiveFromISR( ADC_Int_ADC_Tsk_Semaphore, &xHigherPriorityTaskWoken );
		}
		else if(num_adc_readings_per_ch >= NUM_READING_PER_CH)
		{
			num_adc_readings_per_ch = 0;	// current_ch's 'average' readings over, reset count
			// In ADC module, AD0CR[7:0] -> SEL[7:0], only one bit should be '1' at any time..
			current_adc_channel++;			// go to next ADC channel

			/*********************************************************************//**
			* @brief 		Enable/Disable ADC channel number
			* @param[in]	ADCx pointer to LPC_ADC_TypeDef, should be: LPC_ADC
			* @param[in]	Channel channel number
			* @param[in]	NewState Enable or Disable
			*
			* @return 		None
			**********************************************************************/
			ADC_ChannelCmd (LPC_ADC, current_adc_channel, ENABLE);	// Change to next channel in current cycle
			ADC_StartCmd(LPC_ADC, ADC_START_NOW);					// Start 1st ADC on current_ch in current cycle
		}
		else
		{
			ADC_StartCmd(LPC_ADC, ADC_START_NOW);					// Start next ADC on current_ch in current cycle
		}
	}

	/* Giving the semaphore may have unblocked a task - if it did and the
	unblocked task has a priority equal to or above the currently executing
	task then xHigherPriorityTaskWoken will have been set to pdTRUE and
	portEND_SWITCHING_ISR() will force a context switch to the newly unblocked
	higher priority task.

	NOTE: The syntax for forcing a context switch within an ISR varies between
	FreeRTOS ports.  The portEND_SWITCHING_ISR() macro is provided as part of
	the Cortex-M3 port layer for this purpose. taskYIELD() must never be called from an ISR! */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/

/*
// ISR for I2C0 interrupt
void I2C0_IRQHandler(void)
{
	/***********************************************************************
	 * @brief 		General Master Interrupt handler for I2C peripheral
	 * @param[in]	I2Cx	I2C peripheral selected, should be:
	 * 				- LPC_I2C
	 * 				- LPC_I2C1
	 * 				- LPC_I2C2
	 * @return 		None
	 **********************************************************************
	I2C_MasterHandler(I2C_DUMMY);

	/***********************************************************************
	 * @brief 		Get status of Master Transfer
	 * @param[in]	I2Cx	I2C peripheral selected, should be:
	 *  			- LPC_I2C0
	 * 				- LPC_I2C1
	 * 				- LPC_I2C2
	 * @return 		Master transfer status, could be:
	 * 				- TRUE	master transfer completed
	 * 				- FALSE master transfer have not completed yet
	 **********************************************************************
	if (I2C_MasterTransferComplete(I2C_DUMMY))
	{
		MasterTransferComplete = SET;
	}
}
-----------------------------------------------------------*/

// ISR for I2C1 interrupt
void I2C1_IRQHandler(void)
{
	/*********************************************************************//**
	 * @brief 		General Master Interrupt handler for I2C peripheral
	 * @param[in]	I2Cx	I2C peripheral selected, should be:
	 * 				- LPC_I2C
	 * 				- LPC_I2C1
	 * 				- LPC_I2C2
	 * @return 		None
	 **********************************************************************/
	I2C_MasterHandler(I2C_MASTER);

	/*********************************************************************//**
	 * @brief 		Get status of Master Transfer
	 * @param[in]	I2Cx	I2C peripheral selected, should be:
	 *  			- LPC_I2C0
	 * 				- LPC_I2C1
	 * 				- LPC_I2C2
	 * @return 		Master transfer status, could be:
	 * 				- TRUE	master transfer completed
	 * 				- FALSE master transfer have not completed yet
	 **********************************************************************/
	if (I2C_MasterTransferComplete(I2C_MASTER))
	{
		MasterTransferComplete = SET;
	}
}
/*-----------------------------------------------------------*/

int main( void )
{
	// Initialize the semi-hosting
	printf( "\n" );

	// Create binary semaphores
	ADC_Int_ADC_Tsk_Semaphore = xSemaphoreCreateBinary();
	ADC_Tsk_I2C_Tsk_Semaphore = xSemaphoreCreateBinary();
	EXT_Int_EXT_Tsk_Semaphore = xSemaphoreCreateBinary();

	// The queue is created to hold a maximum of '8 channels, 5 readings each = 40' unsigned int values
    ADCQueue = xQueueCreate( (NUM_READING_PER_CH*NUM_ADC_CH), sizeof( unsigned int ) );

	// Initialize the peripherals/interrupts
	GPIO_Initialization();
	External_Interrupt_Initialization();
	ADC_Initialization();
	I2C_Initialization();

    
	// Create tasks here...
	if( (ADCQueue != NULL) && (ADC_Int_ADC_Tsk_Semaphore != NULL) && (EXT_Int_EXT_Tsk_Semaphore != NULL) && (ADC_Tsk_I2C_Tsk_Semaphore != NULL))
	{
		xTaskCreate(	I2CTask,					// Pointer to the function that implements the task.
						"I2C_Task",					// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						2,							// This task will run at priority
						I2CTaskHandle );			// the task handle.

		xTaskCreate(	ADCTask,					// Pointer to the function that implements the task.
						"ADC_Task",					// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						3,							// This task will run at priority 
						ADCTaskHandle );			// the task handle.

		xTaskCreate(	ButtonTask,					// Pointer to the function that implements the task.
						"Button_Task",				// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						4,							// This task will run at priority 
						ButtonTaskHandle );			// the task handle.

		xTaskCreate(	TimerTask,					// Pointer to the function that implements the task.
						"Timer_Task",				// Text name for the task.  This is to facilitate debugging only.
						250,						// Stack depth in words.
						NULL,						// We are not using the task parameter.
						5,							// This task will run at priority 
						TimerTaskHandle );			// the task handle.

		// Start the scheduler so our tasks start executing
		vTaskStartScheduler();
	}
	else
	{
		#ifdef DEBUG_PRINT	// Debug only
			// The queue could not be created, no space in the heap...
			printf("The queue and/or semaphores could not be created, no space in the heap.\n");
		#endif
	}

	/* If all is well we will never reach here as the scheduler will now be running.  
	If we do reach here then it is likely that there was insufficient heap available for the idle task to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

 // Task to start ADC conversion for each averaging cycle (ch0 - ch7) after 'X' ms intervals
 void TimerTask( void * pvParameters )
 {
	unsigned int i = 0;

	portTickType xLastWakeTime;
	const portTickType WakeUpInterval = 1000 / portTICK_RATE_MS; 	// 'X'

	// Initialize the xLastWakeTime variable with the current time.
	xLastWakeTime = xTaskGetTickCount();

	// Enable ADC interrupt, select channel and start 1st ADC on current_ch in current cycle
	ADC_IntConfig(LPC_ADC, ADC_ADGINTEN, SET);
	ADC_ChannelCmd(LPC_ADC, current_adc_channel, ENABLE);
	ADC_StartCmd(LPC_ADC, ADC_START_NOW);
	NVIC_EnableIRQ(ADC_IRQn);

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		// Periodic interrupts of 'X'ms for the ADC start...
		vTaskDelayUntil( &xLastWakeTime, WakeUpInterval );

		// Perform action here:
		#ifdef DEBUG_PRINT		// Debug only
			printf("\nIn TimerTask\n");
		#endif

		master_wr_index = WRITE_DATA_START;
		master_rd_index = 0;
		// initialize master_wr_buffer, Master_WR_Buffer[0] & [1] are the starting address which is set to '0'
		for(i = 0; i < WR_BUFFER_SIZE; i++) Master_WR_Buffer[i] = 0;
		// initialize master_rd_buffer
		for(i = 0; i < RD_BUFFER_SIZE; i++) Master_RD_Buffer[i] = 0;

		NVIC_EnableIRQ(ADC_IRQn);								// Enable the ADC interrupt
		ADC_ChannelCmd(LPC_ADC, current_adc_channel, ENABLE);	// Enable ADC 'Ch_0'
		ADC_StartCmd(LPC_ADC, ADC_START_NOW);	// Start 1st ADC on current_ch in current cycle
	}
 }
 /*-----------------------------------------------------------*/

// Task to handle the processing from the EXT_INT interrupt using the push button
void ButtonTask( void *pvParameters )
{
	uint32_t port_0_status;

	/* Take the semaphore once to start with so the semaphore is empty before the infinite loop is entered.  
	   The semaphore was created before the scheduler was started so before this task ran for the first time. */
	xSemaphoreTake( EXT_Int_EXT_Tsk_Semaphore, 0 );

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		/* Use the semaphore to wait for the event. The task blocks indefinitely meaning this function call will only return once the
		   semaphore has been successfully obtained - so there is no need to check the returned value. */
		xSemaphoreTake( EXT_Int_EXT_Tsk_Semaphore, portMAX_DELAY );

		// To get here the event must have occurred. Process the event, in this case check if we need to enable/disable smart mode
		port_0_status = GPIO_ReadValue(PORT_0);

		// LED is OFF, turn ON, smart mode 'disabled'/'enable' push button override
		if((port_0_status >> LED_PIN_NUM) & 0x1)
		{
			//smart mode 'disabled'/'enable' push button override
			//printf("Button: LED is OFF turn ON\n");			// Debug only
			GPIO_ClearValue(PORT_0, LED_PIN_BIT);			// LPC_GPIO0->FIOCLR = (1 << 22);
			//led_on_ext_int = true;
		}
		// LED is already ON, turn OFF and 'enable' smart mode/'disable' push button override
		else
		{
			// smart mode 'enable'/'disable' push button override
			//printf("Button: LED is ON turn OFF\n");			// Debug only
			GPIO_SetValue(PORT_0, LED_PIN_BIT);				// LPC_GPIO0->FIOSET = (1 << 22);
			//led_on_ext_int = false;
		}
	}
}
/*-----------------------------------------------------------*/

// Task to handle the data processing from the ADC interrupt
void ADCTask( void *pvParameters )
{
	unsigned int i = 0;
	unsigned int adc_queue_reading = 0;
	unsigned int adc_queue_reading_sum = 0;
	unsigned int adc_average_reading_per_ch;
	unsigned int adc_queue_index = 0;
	
	/* Take the semaphore once to start with so the semaphore is empty before the infinite loop is entered.  
	   The semaphore was created before the scheduler was started so before this task ran for the first time. */
	xSemaphoreTake( ADC_Int_ADC_Tsk_Semaphore, 0 );

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		/* Use the semaphore to wait for the event.  The task blocks indefinitely meaning this function call will only return
		 * once the semaphore has been successfully obtained - so there is no need to check the returned value. */
		xSemaphoreTake( ADC_Int_ADC_Tsk_Semaphore, portMAX_DELAY );

		// To get here the event must have occurred (semaphore acquired).
		// Process the event, in this case read the values from the queue and put into master_buffer
		if((ADCQueue != NULL) && (uxQueueMessagesWaiting(ADCQueue) == (NUM_READING_PER_CH*NUM_ADC_CH)))
		{
			for(i = 0; i <= (NUM_READING_PER_CH*NUM_ADC_CH); i++)
			{
				if(adc_queue_index < NUM_READING_PER_CH)
				{
					// for successful receive from the queue
					if(xQueueReceive(ADCQueue, (void *)&adc_queue_reading, (TickType_t)5 ))
					{
						#ifdef DEBUG_PRINT 		// Debug only
							printf("ADCTask: ADC Queue[%u] = %u \n", i, adc_queue_reading);
						#endif

						adc_queue_reading_sum += adc_queue_reading;
						adc_queue_index++;
					}
				}
				else
				{
					adc_average_reading_per_ch = adc_queue_reading_sum/NUM_READING_PER_CH;

					#ifdef DEBUG_PRINT			// Debug only
						printf("ADCTask: adc_queue_reading_sum = %u \n", adc_queue_reading_sum);
						printf("ADCTask: Avg = %u \n", adc_average_reading_per_ch);
					#endif

					// store data to the master_wr_buffer to transfer to eeprom
					Master_WR_Buffer[master_wr_index] = adc_average_reading_per_ch & 0xFF;
					#ifdef DEBUG_PRINT			// Debug only
						printf("ADCTask: Master_WR_Buffer[%u] = %u \n", master_wr_index, Master_WR_Buffer[master_wr_index]);
					#endif
					master_wr_index++;

					Master_WR_Buffer[master_wr_index] = (adc_average_reading_per_ch >> 8) & 0xFF;
					#ifdef DEBUG_PRINT			// Debug only
						printf("ADCTask: Master_WR_Buffer[%u] = %u \n", master_wr_index, Master_WR_Buffer[master_wr_index]);
					#endif
					master_wr_index++;

					adc_queue_index = 0;
					adc_queue_reading_sum = 0;

					// for successful receive from the queue
					if(xQueueReceive(ADCQueue, (void *)&adc_queue_reading, (TickType_t)5 ))
					{
						#ifdef DEBUG_PRINT 		// Debug only
							printf("ADCTask: ADC Queue[%u] = %u \n", i, adc_queue_reading);
						#endif

						adc_queue_reading_sum += adc_queue_reading;
						adc_queue_index++;
					}
				}
			}

			// re-initialize variables for the next time the task is called...
			adc_queue_reading_sum = 0;
			adc_queue_index = 0;
			current_adc_channel = CHANNEL_0;
			num_adc_readings_per_ch = 0;
			num_adc_readings = 0;

			// disable ADC interrupts until they are enabled again in the timer task..
			NVIC_DisableIRQ(ADC_IRQn);

			xSemaphoreGive( ADC_Tsk_I2C_Tsk_Semaphore );	// 'Give' the semaphore to unblock the I2C handler task
		}
		else
		{
			// The queue could not be created, no space in the heap...
		}
	}
}
/*-----------------------------------------------------------*/

// Task to write to and read from EEPROM thru I2C1 module in master mode
void I2CTask( void * pvParameters )
{
	MasterTransferComplete = RESET;

	/* Take the semaphore once to start with so the semaphore is empty before the infinite loop is entered.
	   The semaphore was created before the scheduler was started so before this task ran for the first time. */
	xSemaphoreTake( ADC_Tsk_I2C_Tsk_Semaphore, 0 );

	// As per most tasks, this task is implemented within an infinite loop.
	for( ;; )
	{
		/* Use the semaphore to wait for the event.  The task blocks indefinitely meaning this function call will only return
		 * once the semaphore has been successfully obtained - so there is no need to check the returned value. */
		xSemaphoreTake( ADC_Tsk_I2C_Tsk_Semaphore, portMAX_DELAY );

		// To get here the event must have occurred (semaphore acquired).
		MasterTransferComplete = RESET;

		// initialize the 'Master_tx_rx_setup' structure to write data to eeprom from address 0x0000
		Master_tx_rx_setup.sl_addr7bit = EEPROM_ADDR_24LC64;
		Master_tx_rx_setup.tx_data = Master_WR_Buffer;
		Master_tx_rx_setup.tx_length = sizeof(Master_WR_Buffer);
		Master_tx_rx_setup.rx_data = NULL;
		Master_tx_rx_setup.rx_length = 0;
		Master_tx_rx_setup.retransmissions_max = 2;

		// start transfer (write data) to eeprom...
		I2C_MasterTransferData(I2C_MASTER, &Master_tx_rx_setup, I2C_TRANSFER_INTERRUPT);

		while(MasterTransferComplete == RESET);

		// initialize the 'Master_tx_rx_setup' structure to read data from eeprom from address 0x0000
		// this involves a write first to set the starting address to read from as 0x000
		// then a repeated start  followed by slave address, then eeprom starts to send the read data
		Master_tx_rx_setup.sl_addr7bit = EEPROM_ADDR_24LC64;
		Master_tx_rx_setup.tx_data = Master_WR_Buffer;
		Master_tx_rx_setup.tx_length = 2;	// 2
		Master_tx_rx_setup.rx_data = Master_RD_Buffer;
		Master_tx_rx_setup.rx_length = sizeof(Master_RD_Buffer);
		Master_tx_rx_setup.retransmissions_max = 2;
		// start transfer (read data) from eeprom...
		I2C_MasterTransferData(I2C_MASTER, &Master_tx_rx_setup, I2C_TRANSFER_INTERRUPT);

		while(MasterTransferComplete == RESET);

		#ifdef DEBUG_PRINT			// Debug only
			printf("\nI2CTask:\n ");

			for(master_wr_index = 0; master_wr_index < WR_BUFFER_SIZE; master_wr_index++)
			{
				printf("Master_WR_Buffer[%u] = %u\n", master_wr_index, Master_WR_Buffer[master_wr_index]);
			}
			printf("-------------------\n\n");

			for(master_rd_index = 0; master_rd_index < RD_BUFFER_SIZE; master_rd_index++)
			{
				printf("Master_RD_Buffer[%u] = %u\n", master_rd_index, Master_RD_Buffer[master_rd_index]);
			}
			printf("-------------------\n\n");
		#endif
	}
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* This function will only be called if an API call to create a task, queue
	or semaphore fails because there is too little heap RAM remaining. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed char *pcTaskName )
{
	/* This function will only be called if a task overflows its stack.  Note
	that stack overflow checking does slow down the context switch
	implementation. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
	/* This example does not use the idle hook to perform any processing. */
}
/*-----------------------------------------------------------*/

void vApplicationTickHook( void )
{
	/* This example does not use the tick hook to perform any processing. */
}
